//
//  ViewController.h
//  000--HelloOpenGLES
//
//  Created by CC老师 on 2019/5/25.
//  Copyright © 2019年 CC老师. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface ViewController : GLKViewController


@end

