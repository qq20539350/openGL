//
//  AppDelegate.h
//  MetalCodeDemo
//
//  Created by CC老师 on 2018/5/28.
//  Copyright © 2018年 CC老师. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

