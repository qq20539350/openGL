//
//  ViewController.h
//  MetalCodeDemo-00
//
//  Created by CC老师 on 2018/5/29.
//  Copyright © 2018年 CC老师. All rights reserved.
//

#import <UIKit/UIKit.h>
@import MetalKit;
#import "CCRenderer.h"

@interface ViewController : UIViewController


@end

