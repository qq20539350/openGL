//
//  AppDelegate.h
//  002--CubeImage
//
//  Created by CC老师 on 2019/4/12.
//  Copyright © 2019年 CC老师. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

