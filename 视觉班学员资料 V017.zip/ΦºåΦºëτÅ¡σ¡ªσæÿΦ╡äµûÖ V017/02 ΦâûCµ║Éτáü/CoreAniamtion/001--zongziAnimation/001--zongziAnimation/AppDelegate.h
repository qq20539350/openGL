//
//  AppDelegate.h
//  001--zongziAnimation
//
//  Created by CC老师 on 2019/6/7.
//  Copyright © 2019年 CC老师. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

