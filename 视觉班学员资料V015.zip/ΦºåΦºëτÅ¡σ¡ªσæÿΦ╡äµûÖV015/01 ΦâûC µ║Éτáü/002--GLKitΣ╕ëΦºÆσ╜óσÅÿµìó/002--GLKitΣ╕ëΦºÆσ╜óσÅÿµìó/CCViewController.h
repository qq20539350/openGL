//
//  CCViewController.h
//  002--GLKit三角形变换
//
//  Created by CC老师 on 2017/12/29.
//  Copyright © 2017年 CC老师. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface CCViewController : GLKViewController

@end
