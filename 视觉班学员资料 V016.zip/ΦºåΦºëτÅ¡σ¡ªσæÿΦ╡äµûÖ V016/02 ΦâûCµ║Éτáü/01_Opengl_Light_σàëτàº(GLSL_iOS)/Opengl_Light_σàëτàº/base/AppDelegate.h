//
//  AppDelegate.h
//  Opengl_Light_光照
//
//  Created by CC老师 on 2019/4/5.
//  Copyright © 2019年 CC老师. All rights reserved.
//



#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

